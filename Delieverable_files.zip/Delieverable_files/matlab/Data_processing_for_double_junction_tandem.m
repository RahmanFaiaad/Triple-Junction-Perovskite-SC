clc;
clear all;

% Thickness ranges for KSnI3 and FASnI3
KSnI3_thickness = 300:50:1100; % Thickness range in nm
FASnI3_thickness = 300:50:1100;

% Directories for data files and results
file_dirc = "I:\Triple-Junction-Project\Project_Formation\8_Dual_Junction_KSnI3_FASnI3_Absorber_contour\Device\V_J_P_mat_files";
output_dirc = "I:\Triple-Junction-Project\Project_Formation\8_Dual_Junction_KSnI3_FASnI3_Absorber_contour\matlab";

% Ask user to select mode
disp('Select mode:');
disp('1 - Plot individual J-V and P-V characteristics for specific thickness');
disp('2 - Perform batch processing and save results');
mode = input('Enter mode (1 or 2): ');

if mode ~= 1 && mode ~= 2
    error('Invalid mode selected. Please enter 1 or 2.');
end

% Initialize result array
results = [];

if mode == 1
    % Ask for specific thickness values
    KSnI3_selected = input('Enter the KSnI3 thickness (nm): ');
    FASnI3_selected = input('Enter the FASnI3 thickness (nm): ');

    % Validate if the input thickness is within the defined range
    if ~ismember(KSnI3_selected, KSnI3_thickness) || ~ismember(FASnI3_selected, FASnI3_thickness)
        error('Thickness values must be within the defined range.');
    end
else
    % No specific inputs needed for mode 2
    KSnI3_selected = NaN; % Dummy placeholder
    FASnI3_selected = NaN; % Dummy placeholder
end

% Loop through thickness combinations
for i = 1:length(KSnI3_thickness)
    for j = 1:length(FASnI3_thickness)
        if mode == 1 && (KSnI3_thickness(i) ~= KSnI3_selected || FASnI3_thickness(j) ~= FASnI3_selected)
            % Skip iterations that do not match the selected thickness
            continue;
        end

        try
            % Top cell data
            top_file = file_dirc + "\J_P_V_KSnI3_top_cell_for_KSnI3_" + num2str(KSnI3_thickness(i)) + "_nm_FASnI3_" + num2str(FASnI3_thickness(j)) + "_nm.mat";
            load(top_file, 'V', 'J', 'P');
            V1 = V;
            J1 = -J; % Convert to standard current density direction
            P1 = P;

            % Middle cell data
            mid_file = file_dirc + "\J_P_V_FASnI3_middle_cell_for_KSnI3_" + num2str(KSnI3_thickness(i)) + "_nm_FASnI3_" + num2str(FASnI3_thickness(j)) + "_nm.mat";
            load(mid_file, 'V', 'J', 'P');
            V2 = V;
            J2 = -J;
            P2 = P;

            % Match current densities
            J_min = min([max(J1), max(J2)]);
            J_tandem = linspace(0, J_min, 100);
            V1_interp = interp1(J1, V1, J_tandem, 'pchip', 'extrap');
            V2_interp = interp1(J2, V2, J_tandem, 'pchip', 'extrap');
            V_tandem = V1_interp + V2_interp;
            
            % Extrapolate: Add the point where V = 0 and J = max(J_tandem)
            J_max = max(J_tandem); % Maximum current density
            V_extrap = [0; V_tandem']; 
            J_extrap = [J_max; J_tandem'];

            % Smooth and extend data
            V_dense = linspace(min(V_extrap), max(V_extrap), 200);
            J_dense = interp1(V_extrap, J_extrap, V_dense, 'pchip');
            
            % Calculate power and performance metrics
            P_tandem = J_dense .* V_dense;
            %Find the Maximum Power Point (Pmax)
            [Pmax, idx_max] = max(P_tandem); % Maximum power and its index
            %Pmax = max(P_tandem);
            Voc = max(V_dense); % Open-circuit voltage
            Jsc = max(J_dense); % Short-circuit current density
            FF = (Pmax / (Voc * Jsc)) * 100; % Fill factor
            eta = (Pmax / 100) * 100; % eta, assuming 100 mW/cm^2 irradiance
            

            % Find Voltage at Maximum Power Point
            V_mpp = V_dense(idx_max); % Voltage corresponding to Pmax

            % Save results for current configuration
            %results = [results; KSnI3_thickness(i), FASnI3_thickness(j), eta, Jsc, Voc, FF, Pmax_wm2, V_mpp];
            results = [results; KSnI3_thickness(i), FASnI3_thickness(j), eta, Jsc, Voc, FF, Pmax, V_mpp];

            % Plotting for mode 1
            if mode == 1

                  % Customizable font sizes
                    xlabel_fontsize = 12; % Adjust as needed
                    ylabel_fontsize = 12; % Adjust as needed

                    figure;

                    % Set figure position
                    set(gcf, 'Position', [50, 50, 1000, 350]);

                    % Subplot 1: J-V Curve
                    subplot(1, 2, 1);
                    plot(V1, J1, 'r', 'LineWidth', 1.5, 'DisplayName', 'Top Junction');
                    hold on;
                    plot(V2, J2, 'g', 'LineWidth', 1.5, 'DisplayName', 'Middle Junction');
                    %plot(V3, J3, 'b', 'LineWidth', 1.5, 'DisplayName', 'Bottom Junction');
                    plot(V_dense, J_dense, 'k', 'LineWidth', 2, 'DisplayName', 'Double Tandem Cell');
                    hold off;
                    xlabel('Voltage (V)', 'Fontweight', 'bold', 'FontSize', xlabel_fontsize);
                    ylabel('J_{sc} (mA/cm^2)', 'Fontweight', 'bold', 'FontSize', ylabel_fontsize);
                    legend show;
                    legend boxoff;
                    lgd1 = legend; % Create legend and store handle
                    set(lgd1, 'FontWeight', 'bold'); % Make legend text bold
                    ylim([0, max([max(J1), max(J2)])+ 4]);

                    % Bold x-tick labels
                    ax1 = gca;
                    ax1.XAxis.FontWeight = 'bold';
                    ax1.YAxis.FontWeight = 'bold';

                    % Subplot 2: P-V Curve
                    subplot(1, 2, 2);
                    plot(V1, P1, 'r', 'LineWidth', 1.5, 'DisplayName', 'Top Junction');
                    hold on;
                    plot(V2, P2, 'g', 'LineWidth', 1.5, 'DisplayName', 'Middle Junction');
                    %plot(V3, P3, 'b', 'LineWidth', 1.5, 'DisplayName', 'Bottom Junction');
                    plot(V_dense, P_tandem, 'k', 'LineWidth', 2, 'DisplayName', 'Double Tandem Cell');
                    hold off;
                    xlabel('Voltage (V)', 'Fontweight', 'bold', 'FontSize', xlabel_fontsize);
                    ylabel('\eta (%)', 'Fontweight', 'bold', 'FontSize', ylabel_fontsize);
                    legend show;
                    legend boxoff;
                    lgd1 = legend; % Create legend and store handle
                    set(lgd1, 'FontWeight', 'bold'); % Make legend text bold

                    % Bold x-tick labels
                    ax2 = gca;
                    ax2.XAxis.FontWeight = 'bold';
                    ax2.YAxis.FontWeight = 'bold';
             end
        catch ME
            fprintf('Error processing data for KSnI3 = %d nm, FASnI3 = %d nm: %s\n', ...
                    KSnI3_thickness(i), FASnI3_thickness(j), ME.message);
        end
    end
end

% Write results to a file for mode 2
if mode == 2
    output_file = fullfile(output_dirc, 'KSnI3_FASnI3_dual_junction_solar_cell_sweep_results.txt');
    fileID = fopen(output_file, 'w');
    if fileID == -1
        error('Failed to open file for writing: %s', output_file);
    end
    fprintf(fileID, 'KSnI3(nm)\tFASnI3(nm)\teta(%%)\tJsc(mA/cm^2)\tVoc(V)\tFF(%%)Pmpp(W/m^2)\tVmpp(V)\n');
    fprintf(fileID, '%d\t%d\t%.3f\t%.3f\t%.3f\t%.3f\t%.3f\t%.3f\n', results');
    fclose(fileID);
    disp('Results successfully written to file.');
end

% Helper function to validate scalars
function value = validateScalar(value)
    if isempty(value)
        value = 0;  % Default to 0 if empty
    end
end
