clc;
clear all;

% Load data
infile = "I:\Triple-Junction-Project\Project_Formation\8_Dual_Junction_KSnI3_FASnI3_Absorber_contour\matlab\KSnI3_FASnI3_dual_junction_solar_cell_sweep_results.csv";
if exist(infile, 'file') ~= 2
    error('File not found: %s', infile);
end

z = fopen(infile);
c = textscan(z, '%s', 'delimiter', '\n');
fclose(z);

% Pre-allocate arrays for better performance
X_val = zeros(size(c{1,1}));
Y_val = zeros(size(c{1,1}));
E_ta = zeros(size(c{1,1}));
J_sc = zeros(size(c{1,1}));
V_oc = zeros(size(c{1,1}));
FF = zeros(size(c{1,1}));

% Parse data
for idx = 1:size(c{1,1}, 1)
    sor_st = c{1,1}{idx};
    splited = split(sor_st, ",");
    X_val(idx) = str2num(splited{1});
    Y_val(idx) = str2num(splited{2});
    E_ta(idx) = str2num(splited{3});
    J_sc(idx) = str2num(splited{4});
    V_oc(idx) = str2num(splited{5});
    FF(idx) = str2num(splited{6});
end

% Use griddata for interpolation
[X_grid, Y_grid] = meshgrid(unique(X_val), unique(Y_val));
E_ta_r = griddata(X_val, Y_val, E_ta, X_grid, Y_grid, 'cubic');
J_sc_r = griddata(X_val, Y_val, J_sc, X_grid, Y_grid, 'cubic');
V_oc_r = griddata(X_val, Y_val, V_oc, X_grid, Y_grid, 'cubic');
FF_r = griddata(X_val, Y_val, FF, X_grid, Y_grid, 'cubic');

% Create a square matrix for contourf
figure;
ax.FontSize = 11;
ax.FontWeight = 'Bold';
ax.YAxis.FontSize = 10; % for y-axis
ax.XAxis.FontSize = 10; % for x-axis

% Subplot 1 - Efficiency
subplot(2, 2, 1);
contourf(X_grid, Y_grid, E_ta_r, 'LineStyle', 'none', 'LevelList', linspace(min(E_ta(:)), max(E_ta(:)), 100));
colormap Jet; % Set the colormap to Jet
title("\eta (%)", 'FontSize', 12, 'FontWeight', 'bold');
xlabel('t_{ KSnI_{3}} Absorber (nm)', 'FontSize', 10, 'FontWeight', 'bold');
ylabel('t_{ FASnI_{3}} Absorber (nm)', 'FontSize', 10, 'FontWeight', 'bold');
colorbar;
hold on;
contour(X_grid, Y_grid, E_ta_r, 'LineColor', 'k'); % Add black contour lines
hold off;

% Make the color bar levels bold
h = colorbar;
set(h, 'FontWeight', 'bold');

% Subplot 2 - J_sc (Short-circuit current density)
subplot(2, 2, 2);
contourf(X_grid, Y_grid, J_sc_r, 'LineStyle', 'none', 'LevelList', linspace(min(J_sc(:)), max(J_sc(:)), 100));
colormap Jet; % Set the colormap to Jet
title("J_{sc}(mA/cm^2)", 'FontSize', 12, 'FontWeight', 'bold');
xlabel('t_{ KSnI_{3}} Absorber (nm)', 'FontSize', 10, 'FontWeight', 'bold');
ylabel('t_{ FASnI_{3}} Absorber (nm)', 'FontSize', 10, 'FontWeight', 'bold');
colorbar;
hold on;
contour(X_grid, Y_grid, J_sc_r, 'LineColor', 'k'); % Add black contour lines
hold off;

% Make the color bar levels bold
h = colorbar;
set(h, 'FontWeight', 'bold');

% Subplot 3 - V_oc (Open-circuit voltage)
subplot(2, 2, 3);
contourf(X_grid, Y_grid, V_oc_r, 'LineStyle', 'none', 'LevelList', linspace(min(V_oc(:)), max(V_oc(:)), 100));
colormap Jet; % Set the colormap to Jet
title("V_{oc}(V)", 'FontSize', 12, 'FontWeight', 'bold');
xlabel('t_{ KSnI_{3}} Absorber (nm)', 'FontSize', 10, 'FontWeight', 'bold');
ylabel('t_{ FASnI_{3}} Absorber (nm)', 'FontSize', 10, 'FontWeight', 'bold');
colorbar;
hold on;
contour(X_grid, Y_grid, V_oc_r, 'LineColor', 'k'); % Add black contour lines
hold off;

% Make the color bar levels bold
h = colorbar;
set(h, 'FontWeight', 'bold');

% Subplot 4 - Fill Factor (FF)
subplot(2, 2, 4);
contourf(X_grid, Y_grid, FF_r, 'LineStyle', 'none', 'LevelList', linspace(min(FF(:)), max(FF(:)), 100));
colormap Jet; % Set the colormap to Jet
title("FF(%)", 'FontSize', 12, 'FontWeight', 'bold');
xlabel('t_{ KSnI_{3}} Absorber (nm)', 'FontSize', 10, 'FontWeight', 'bold');
ylabel('t_{ FASnI_{3}} Absorber (nm)', 'FontSize', 10, 'FontWeight', 'bold');
colorbar;
hold on;
contour(X_grid, Y_grid, FF_r, 'LineColor', 'k'); % Add black contour lines
hold off;

% Make the color bar levels bold
h = colorbar;
set(h, 'FontWeight', 'bold');
